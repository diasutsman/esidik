<!DOCTYPE html>
<html lang="en">
<head>
<title>404 Page Not Found</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />
	<link href="<?php echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url()?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">

	<link href="<?php echo base_url()?>assets/css/animate.css" rel="stylesheet">
	<link href="<?php echo base_url()?>assets/css/style.css" rel="stylesheet">

</head>
<body class="gray-bg">


<div class="middle-box text-center animated fadeInDown">
	<h1>404</h1>
	<h3 class="font-bold">Halaman tidak ditemukan!!!</h3>

	<div class="error-desc">
		Mohon maaf, halaman yang anda cari tidak temukan. Silakan periksa kembali kesalahan pada URL, lalu klik tombol refresh pada browser anda atau terjadi kesalah pada aplikasi ini.
	</div>
</div>

<script src="<?php echo base_url()?>assets/js/jquery-2.1.1.js"></script>
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>

</body>
</html>