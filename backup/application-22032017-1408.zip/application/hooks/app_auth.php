<?php
/**
 * File: app_auth.php
 * Author: abdiIwan.
 * Date: 1/4/2017
 * Time: 10:47 PM
 * absensi.kemendagri.go.id
 */

class App_auth
{
    protected  $CI;

    public function App_auth()
    {

    }

    public function index()
    {
        $this->CI = get_instance();

        $thn = $this->CI->db->get_where("bukatutup",array("idbln"=>date("m"),"tahun"=>date("Y")));
        if ($thn->num_rows()==0 )
        {
            $this->CI->load->model('utils_model','utils');

            $arbln = $this->CI->utils->getBulan();
            $dataIn['idbln'] = date("m");
            $dataIn['tahun'] =  date("Y");
            $dataIn['status'] =  1;
            $dataIn['bulan'] =  $arbln[intval(date("m"))];
            $this->CI->db->insert('bukatutup', $dataIn);
        }

        /*if ($this->CI->session->userdata("s_id") == "")  // If no session found redirect to login page.
        {
            redirect(site_url('login'));
        }*/
    }
}