<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

class Utils_model extends CI_Model{
	
	function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	function validation($username, $password)
	{
        $sql = "SELECT *
              FROM users 
              WHERE username = ? AND password_md5 = ? ";
        $query = $this->db->query($sql, array($username,md5($password)));
        //die($this->db->last_query());
		return $query;
	}

    function validationold($username, $password)
    {
        $sql = "SELECT a.username AS userid, a.nama, a.password, a.id_user_group AS groupid, a.email, a.nip, '' AS kunker 
              FROM tb_user a, peg_identpeg c WHERE a.username = ? AND a.password = ? 
              AND c.nip = a.nip AND c.aktif = 1";
        $query = $this->db->query($sql, array($username,sha1(md5($password))));
        //die($this->db->last_query());
        return $query;
    }
	
	function insert_online($user='')
	{
		$uvisitor = getRealIpAddr().' | '.$this->session->userdata('user_agent');
		$utime=time();
		$exptime=$utime-600; // (in seconds)

		$sql1 = "DELETE FROM tonline WHERE tonline_timevisit < $exptime";
		$this->db->query($sql1);

		$sql2 = "SELECT tonline_id FROM tonline WHERE tonline_visitor = '$uvisitor'";
		$res = $this->db->query($sql2);

		if ($res->num_rows() > 0){
			$sql = "UPDATE tonline SET tonline_timevisit='$utime', userid = '$user' WHERE tonline_visitor='$uvisitor'";
		} else {
			$sql = "INSERT INTO tonline (tonline_visitor, tonline_timevisit, userid) VALUES ('$uvisitor','$utime', '$user')";
		}
		$this->db->query($sql);
		
		$sq = "SELECT tonline_id FROM tonline WHERE tonline_visitor = '$uvisitor'";
		$query = $this->db->query($sq);
		return $query;
	}
	
	function update_user($id,$dataIn)
	{
		$this->db->where('username', $id);
		$this->db->update('users',$dataIn);
	}
	
	function delete_online($user)
	{
		$this->db->where('tonline_id', $user);
		$delete = $this->db->delete('tonline');
		return $delete;
	}
	

	function get_user($username)
	{
		$sql =  "SELECT * from users where id ='".$username."'";
		$query = $this->db->query($sql);

		return $query;
	}

	function getStatusPegawai()
    {
        $arr["1"] = "CPNS";
        $arr["2"] = "PNS";
        $arr["3"] = "PENSIUNAN";
        $arr["4"] = "MENINGGAL";
        $arr["5"] = "BERHENTI";
        $arr["6"] = "PINDAH WILAYAH KERJA";
        $arr["7"] = "HONORER";
        $arr["8"] = "MASA PERSIAPAN PENSIUN (MPP)";

        return $arr;
    }

    /*function getStatusPegawai()
    {
        $arr["0"] = "AKTIF";
        $arr["1"] = "NON AKTIF";

        return $arr;
    }*/

    function getJenisJabatan()
    {
        $arr["1"] = "Struktural";
        $arr["2"] = "Fungsional Tertentu";
        $arr["3"] = "Negara";
        $arr["4"] = "Fungsional Umu";
        $arr["5"] = "KORPRI";
        return $arr;
    }

    function getJenisPegawai()
    {
        $arr["1"] = "PNSP KEMENDAGRI";
        $arr["2"] = "PNS INSTANSI LAIN DPK";
        $arr["3"] = "PNSP KEMENDAGRI DPK PD INSTANSI LAIN";
        $arr["4"] = "PRAJA IPDN";
        $arr["5"] = "JENIS KEPEGAWAIAN LAIN-LAIN / TITIPAN";
        $arr["6"] = "Jenpeg Sementara";
        $arr["7"] = "KELUAR DARI KEMENDAGRI";
        $arr["8"] = "PNS PADA BNPP";
        return $arr;
    }

    function getKedudukanPegawai()
    {
        $arr["1"] = "AKTIF";
        $arr["2"] = "CUTI LUAR TANGGUNGAN NEGARA (CLTN)";
        $arr["3"] = "PERPANJANGAN CLTN";
        $arr["4"] = "TUGAS BELAJAR";
        $arr["5"] = "PEMBERHENTIAN SEMENTARA";
        $arr["6"] = "PENERIMA UANG TUNGGU";
        $arr["7"] = "WAJIB MILITER";
        $arr["8"] = "PNS YANG DINYATAKAN HILANG";
        $arr["9"] = "PEJABAT NEGARA";
        $arr["10"] = "KEPALA DESA";
        $arr["11"] = "KEBERATAN ATAS PENJATUHAN HUKUMAN DISIPLIN SESUAI PP30/1980";
        $arr["12"] = "MASA PERSIAPAN PENSIUN";
        $arr["13"] = "PEGAWAI TITIPAN";
        $arr["14"] = "CUTI SAKIT";
        return $arr;
    }

    function getBulan()
    {
        $arr[1] = "Januari";
        $arr[2] = "Februari";
        $arr[3] = "Maret";
        $arr[4] = "April";
        $arr[5] = "Mei";
        $arr[6] = "Juni";
        $arr[7] = "Juli";
        $arr[8] = "Agustus";
        $arr[9] = "September";
        $arr[10] = "Oktober";
        $arr[11] = "November";
        $arr[12] = "Desember";
        return $arr;
    }

    function getShift()
    {
        $query = $this->db->get("master_shift");

        return $query;
    }

    function getAgama()
    {
        return array("ISLAM"=>"ISLAM","KRISTEN PROTESTAN"=>"KRISTEN PROTESTAN","KRISTEN KATHOLIK"=>"KRISTEN KATHOLIK",
            "HINDU"=>"HINDU","BUDHA"=>"BUDHA","KONGHUCU"=>"KONGHUCU","KEPERCAYAAN"=>"KEPERCAYAAN","LAINNYA"=>"LAINNYA");
    }

    function getGender()
    {
        return array("1"=>"Laki-laki","2"=>"Perempuan");
    }

    function getEselon()
    {
        return $this->db->get("ref_eselon");
    }

    function getuser($areaid)
    {
        $this->db->select('a.userid, a.name');
        $this->db->from('userinfo a');
        $this->db->join('userinfo_attarea b', 'a.userid=b.userid');
        $this->db->where_in('b.areaid', $areaid);
        $this->db->group_by('a.userid');
        return $this->db->get();
    }

    function getuserbyuser($userid)
    {
        $this->db->select('userid, name, deptid');
        $this->db->from('userinfo');
        $this->db->where_in('userid', $userid);
        return $this->db->get();
    }

    function getuserbyorg($orgid)
    {
        $this->db->select('userid, name, deptid');
        $this->db->from('userinfo');
        $this->db->where_in('deptid', $orgid);
        return $this->db->get();
    }

    function getuserbyorgemail($orgid)
    {
        $sql = "select userid, name, deptid from userinfo ";
        $s = array();
        foreach($orgid as $ar)
            $s[] = "'".$ar."'";
        $sql .= "where deptid in (".implode(',', $s).") and active is null";

        return $this->db->query($sql);
    }

    function getuserorg($areaid, $deptid)
    {
        $this->db->select('a.userid, a.name');
        $this->db->from('userinfo a');
        $this->db->join('userinfo_attarea b', 'a.userid=b.userid');
        $this->db->where_in('b.areaid', $areaid);
        $this->db->where_in('a.deptid', $deptid);
        $this->db->group_by('a.userid');
        return $this->db->get();
    }


    function getshiftuserid($userid, $datestart, $dateend)
    {
        $this->db->from('view_rosterdetails');
        $this->db->where('rosterdate >=', date('Y-m-d', $datestart));
        $this->db->where('rosterdate <=', date('Y-m-d', $dateend));
        $this->db->where_in('userid', $userid);
        $query = $this->db->get();
        return $query->result();
    }

    function getshiftorgid($orgid, $datestart, $dateend)
    {
        $this->db->from('view_rosterdetails');
        $this->db->where('rosterdate >=', date('Y-m-d', $datestart));
        $this->db->where('rosterdate <=', date('Y-m-d', $dateend));
        $this->db->where_in('deptid', $orgid);
        $query = $this->db->get();
        return $query->result();
    }

    function getshiftgroupdetails($userid, $datestart, $dateend)
    {
        $this->db->select('a.userid, rosterdate, attendance, notes, b.emptype');
        $this->db->from('groupshiftdetails a');
        $this->db->join('userinfo b', 'a.userid=b.userid', 'left');
        $this->db->where('rosterdate >=', date('Y-m-d', $datestart));
        $this->db->where('rosterdate <=', date('Y-m-d', $dateend));
        $this->db->where_in('a.userid', $userid);
        $query = $this->db->get();
        return $query->result();
    }

    function getshiftgroupdetailsorg($orgid, $datestart, $dateend)
    {
        $this->db->select('a.userid, rosterdate, attendance, notes, b.emptype');
        $this->db->from('groupshiftdetails a');
        $this->db->join('userinfo b', 'a.userid=b.userid', 'left');
        $this->db->where('rosterdate >=', date('Y-m-d', $datestart));
        $this->db->where('rosterdate <=', date('Y-m-d', $dateend));
        $this->db->where_in('deptid', $orgid);
        $query = $this->db->get();
        return $query->result();
    }

    function getgroupshift()
    {
        $this->db->from('view_groupdetails');
        $query = $this->db->get();
        return $query->result();
    }

    function getawal($userid, $opt1, $opt2)
    {
        $this->db->select_min('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('checktime >=', $opt1);
        $this->db->where('checktime <=', $opt2);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function getawalpmd($userid, $opt1, $opt2)
    {
        $this->db->select_min('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('checktime >=', $opt1);
        $this->db->where('checktime <=', $opt2);
        $this->db->where('checktype', '0');
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function getawalgroup($userid, $opt1)
    {
        $this->db->select_min('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('date(checktime)', $opt1);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function getakhirgroup($userid, $opt1)
    {
        $this->db->select_max('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('date(checktime)', $opt1);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function getawalsplit1($userid, $tanggal)
    {
        $this->db->select_min('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('date(checktime)', $tanggal);
        $this->db->where('checktype', 0);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function getawalsplit2($userid, $tanggal)
    {
        $this->db->select_min('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('date(checktime)', $tanggal);
        $this->db->where('checktype', 4);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function adatranslog($userid, $tanggal)
    {
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('date(checktime)', $tanggal);
        $query = $this->db->get();
        if($query->num_rows()>=1)
        {
            return true;
        }
        return false;
    }

    function getakhir($userid, $opt1, $opt2)
    {
        $this->db->select_max('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('checktime >=', $opt1);
        $this->db->where('checktime <=', $opt2);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function getakhirpmd($userid, $opt1, $opt2)
    {
        $this->db->select_max('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('checktime >=', $opt1);
        $this->db->where('checktime <=', $opt2);
        $this->db->where('checktype', '1');
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function getakhirsplit1($userid, $tanggal)
    {
        $this->db->select_min('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('date(checktime)', $tanggal);
        $this->db->where('checktype', 1);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function getakhirsplit2($userid, $tanggal)
    {
        $this->db->select_min('checktime');
        $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('date(checktime)', $tanggal);
        $this->db->where('checktype', 5);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->checktime;
        }
        return false;
    }

    function savetemp($data)
    {
        if($this->db->insert('process', $data))
        {
            return true;
        }
        return false;
    }

    function cekotsetting()
    {
        $this->db->select('field_id, field_value');
        $this->db->from('general_setting');
        $query = $this->db->get();
        return $query;
    }

    function cekotafter()
    {
        $this->db->from('general_setting');
        $this->db->where('field_name', 'ot_after');
        $query = $this->db->get();
        if($query->row()->field_value == 0) {
            return true;
        }
        return false;
    }

    function cekholiday($datestart, $dateend)
    {
        $this->db->from('holiday');
        if(!empty($orgid)) {
            $s = array();
            foreach($orgid as $ar)
                $s[] = (string)$ar;
            $this->db->where_in('deptid', implode(',', $s));
        }
        $this->db->or_where('deptid', '1');
        return $this->db->get();
    }

    function cekworkday($tgl)
    {
        $this->db->from('tbl_workingday');
        $this->db->where('id_day', $tgl);
        $query = $this->db->get();
        if($query->row()->status_workingday == 0) {
            return true;
        }
        return false;
    }

    function getedit($userid, $tgl)
    {
        /* $this->db->from('checkinout');
        $this->db->where('userid', $userid);
        $this->db->where('checktime', $tgl);
        $this->db->where('checktype', '20');
        $query = $this->db->get();
        if($query->num_rows()==1) {
            return 1;
        } */
        return 0;
    }

    function getprocesseddata($awal, $akhir)
    {
        $this->db->select('id, userid, date_shift');
        $this->db->from('process');
        $this->db->where('date_shift >=', date('Y-m-d', $awal));
        $this->db->where('date_shift <=', date('Y-m-d', $akhir));
        $query = $this->db->get();
        if($query->num_rows()>=1) {
            return $query;
        }
        return false;
    }

    function getprocesseddataid($userid, $awal, $akhir)
    {
        $this->db->select('id, userid, date_shift');
        $this->db->from('process');
        $this->db->where('userid', $userid);
        $this->db->where('date_shift >=', date('Y-m-d', $awal));
        $this->db->where('date_shift <=', date('Y-m-d', $akhir));
        $query = $this->db->get();
        if($query->num_rows()>=1) {
            return $query;
        }
        return false;
    }

    function getprocesssetting() {
        $this->db->select('value');
        $this->db->from('process_setting');
        $this->db->where('id', 1);
        $query = $this->db->get();
        if($query->num_rows()==1)
        {
            return $query->row()->value;
        }
        return false;
    }

    function createDateRangeArray($strDateFrom,$strDateTo)
    {
        $aryRange=array();
        $iDateFrom=mktime(1,0,0,substr($strDateFrom,5,2), substr($strDateFrom,8,2),substr($strDateFrom,0,4));
        $iDateTo=mktime(1,0,0,substr($strDateTo,5,2), substr($strDateTo,8,2),substr($strDateTo,0,4));

        if ($iDateTo>=$iDateFrom) {
            array_push($aryRange,date('Y-m-d',$iDateFrom)); // first entry

            while ($iDateFrom<$iDateTo) {
                $iDateFrom+=86400; // add 24 hours
                array_push($aryRange,date('Y-m-d',$iDateFrom));
            }
        }
        return $aryRange;
    }





}