<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

	function make_menu(){
		$CI =& get_instance();
		$menunav = '';
		$menu = $CI->session->userdata('menu');
		$user_id = $CI->session->userdata('s_access');
		if($user_id==1){
			$sql = "select * from tmenu where aplikasiid = 3 and parentid=0 and show_on_menu=1 order by urutan asc";
		}else{
			$sql = "SELECT tmenu.menuid, namamenu, linkaction2, target, image 
					FROM trgroupmenu
					LEFT JOIN tmenu ON trgroupmenu.menuid = tmenu.menuid
					WHERE aplikasiid = '3' AND groupid = '".$user_id."' AND parentid = 0 and tmenu.show_on_menu=1 and tmenu.status=1 ORDER BY urutan";
		}
		
		$query = $CI->db->query($sql);
		$i=0;
		foreach($query->result_array() as $row)
		{
			if(toogle($row['menuid'],$user_id) > 0){
				$class = ($row['menuid']==$menu)?'active':'';
				$menunav .= "<li class='dropdown ".$class."'>";
				$menunav .= '<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<i class="'.$row['image'].'"></i>
								<span>'.$row['namamenu'].'</span>
								<b class="caret"></b>
							</a>';
				$menunav .=	formatTree($row['menuid'],$user_id);
				$menunav .= "</li>";
			}else{
				$class = ($row['menuid']==$menu)?'active':'';
				$menunav .= "<li class='".$class."'>";
				$menunav .= '<a href="'.site_url($row['linkaction2']).'">
								<i class="'.$row['icon'].'"></i>
								<span>'.$row['namamenu'].'</span>
							</a>';
				$menunav .= "</li>";
			}
			$i++;
		}
		
		echo $menunav;
	}		
	
	function formatTree($id_parent,$user_id){
		$CI =& get_instance();
		if($user_id==1){
			$sql = "select * from tmenu where parentid='".$id_parent."' AND aplikasiid = 3 and tmenu.show_on_menu=1 and tmenu.status=1 ORDER BY urutan asc";
		}else{
			$sql = "SELECT tmenu.menuid, namamenu, linkaction2, target, image 
					FROM trgroupmenu
					LEFT JOIN tmenu ON trgroupmenu.menuid = tmenu.menuid
					WHERE aplikasiid = '3' AND groupid = '".$user_id."' AND parentid = '".$id_parent."' and tmenu.show_on_menu=1 and tmenu.status=1 ORDER BY urutan";
		}
		
		$query = $CI->db->query($sql);
		$menunav = "<ul class='dropdown-menu'>";
        foreach($query->result_array() as $item){
			if(toogle($item['menuid'],$user_id) > 0){
				$menunav .= "<li>";
				$menunav .= '<a href="javascript:;" class="dropdown-toggle">'.$item['namamenu'].' <b class="caret"></b></a>';
				$menunav.= formatTree($item['menuid'],$user_id);
				$menunav.= "</li>";		
			}else{
				$menunav .= "<li>";
				$menunav .= '<a href="'.site_url($item['linkaction2']).'">'.$item['namamenu'].'</a>';
				$menunav.= "</li>";	
			}
        }

      $menunav.= "</ul>";
	  return $menunav;
    }
	
	function toogle($id_parent,$user_id){
		$CI =& get_instance();
		if($user_id==1){
			$sql = "select * from tmenu where parentid='".$id_parent."' AND aplikasiid = 3 and tmenu.show_on_menu=1 and tmenu.status=1 ORDER BY urutan asc";
		}else{
			$sql = "SELECT tmenu.menuid, namamenu, linkaction2, target, image 
					FROM trgroupmenu
					LEFT JOIN tmenu ON trgroupmenu.menuid = tmenu.menuid
					WHERE aplikasiid = '3' AND groupid = '".$user_id."' AND parentid = '".$id_parent."' and tmenu.show_on_menu=1 and tmenu.status=1 ORDER BY urutan";
		}
		$query = $CI->db->query($sql);
		return $query->num_rows();
    }
?>