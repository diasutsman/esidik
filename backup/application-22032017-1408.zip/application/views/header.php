<?php
/**
 * File: header.php
 * Author: abdiIwan.
 * Date: 12/23/2016
 * Time: 4:56 PM
 * absensi.kemendagri.go.id
 */
?>
<script src="<?php echo base_url()?>assets/js/jquery-2.1.1.js"></script>
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js" ></script>
<link href="<?php echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">
<!--<link href="<?php /*echo base_url()*/?>assets/css/font_google.css" rel="stylesheet">-->
<link href="<?php echo base_url()?>assets/css/animate.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/css/style.css" rel="stylesheet">

