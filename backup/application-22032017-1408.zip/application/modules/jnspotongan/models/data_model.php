<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

class Data_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function getDaftar()
    {
        $rstl = $this->db->get("ref_jnspot");
        return $rstl;
    }


}         