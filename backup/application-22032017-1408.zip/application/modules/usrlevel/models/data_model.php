<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

class Data_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function getDaftar($dipaging=0,$limit=10,$offset=1,$id=null,$cari=null,$count=0)
    {
        $sql =  "SELECT ".((isset($count) && $count ==1)?'count(*) as total':'*')." 
		 from user_level
		Where (1=1)";
        if($id!='' && $id !=null) $sql .= " AND a.user_level_id='".$id."' ";
        if($cari!='' && $cari !=null) $sql .= " $cari ";
        $sql .=" order by user_level_id desc ";
        if (isset($dipaging) && $dipaging ==1) {
            $sql .= " limit $offset, $limit ";
        }
        //echo $sql;
        return $this->db->query($sql);

        return $qry;
    }


}         