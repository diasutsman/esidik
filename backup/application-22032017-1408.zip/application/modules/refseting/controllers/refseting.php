<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Refseting extends MY_Controller {

	function Refseting(){
		parent::__construct();
		$this->load->helper('utility');
		$this->load->helper('menunavigasi');
		$this->load->library('mypagination' );

		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');

	}


	function killSession()
	{
	}
	
	function index()
	{
		$this->killSession();
		$this->index_list();
	}
	
	function index_list()
	{
		$this->session->set_userdata('menu','9');
		$data['menu'] = '9';

        $data['result'] = $this->db->get("company")->row_array();

		$this->template->load('template','display',$data);
	}

    public function save()
    {
        $idkx = $this->db->get("company");

        $idx = $idkx->num_rows();

        $t1 = $this->input->post('txt1');
        $t2 = $this->input->post('txt2');
        $t3 = $this->input->post('txt3');
        $t4 = $this->input->post('txt4');
        $t5 = $this->input->post('txt5');
        $t6 = $this->input->post('txt6');

        $dataIn['companyname'] = $t1;
        $dataIn['address1'] =  $t2;
        $dataIn['phone'] =  $t3;
        $dataIn['fax'] =  $t4;
        $dataIn['thp'] =  $t5;
        $dataIn['plt'] =  $t6;

        if ($idx==0)
        {
            $insert = $this->db->insert('company', $dataIn);
            if (!$insert) {

                $data['msg'] = 'Maaf, Tidak bisa menyimpan data..';
                $data['status'] = 'error';

            } else {

                $data['msg'] = 'Data berhasil disimpan..';
                $data['status'] = 'succes';
            }
        }
        else
        {
            $update = $this->db->update('company',$dataIn);
            if(!$update){

                $data['msg'] = 'Maaf, Tidak bisa merubah data..';
                $data['status'] = 'error';

            }else{
                $data['msg'] = 'Data berhasil dirubah..';
                $data['status'] = 'succes';
            }
        }
        die(json_encode($data));
    }




}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */