<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends MY_Controller {

	function Home(){
		parent::__construct();
		$this->load->helper('utility');
		$this->load->helper('menunavigasi');
		$this->load->library('mypagination' );

		$this->load->model('home_model','home');

		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');
	}


	function killSession()
	{
	}
	
	function index()
	{
		$this->killSession();
		$this->index_list();
	}
	
	function index_list()
	{

		$this->session->set_userdata('menu','0');
		$data['menu'] = '0';
        $lsttransaksi = $this->home->getLastDayTrans();
        $data['lsttransaksi'] = ymdTodmy($lsttransaksi);

        $lstprocess = $this->home->getLastDayProcess();
        $data['lstprocess'] = ymdTodmy($lstprocess);

        $data['jmlTepatWaktu'] = $this->home->getTptwaktu($lstprocess);
        $data['jmlTerlambat'] = $this->home->getTerlambat($lstprocess);
        $data['jmlIjin'] = $this->home->getIjin($lstprocess);
        $data['jmlAlpha'] = $this->home->getAlpha($lstprocess);
        $data['jmlSakit'] = $this->home->getSakit($lstprocess);
        $data['jmlCuti'] = $this->home->getCuti($lstprocess);
        $data['thn'] = date("Y",strtotime($lstprocess));

        $data['lsthariini'] = $this->home->getLastAbsensi($lsttransaksi,5);
        $data['lstTepatWaktu'] = $this->home->getTptwaktuByYear($data['thn']);
        $data['lstTerlambat'] = $this->home->getTerlambatByYear($data['thn']);
        $data['lstIjin'] = $this->home->getIjinByYear($data['thn']);
        $data['lstlAlpha'] = $this->home->getAlphaByYear($data['thn']);
        $data['lstSakit'] = $this->home->getSakitByYear($data['thn']);
        $data['lstCuti'] = $this->home->getCutiByYear($data['thn']);

		$this->template->load('template','home',$data);
	}

	function kuncipage()
    {

        $this->load->view('kuncipage');
    }

    function tryunlock()
    {
        $this->load->view('kuncipage');
    }
	

}
