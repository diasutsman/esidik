<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Profile extends MY_Controller {

	function Profile(){
		parent::__construct();
		$this->load->helper('utility');
		$this->load->helper('menunavigasi');
		$this->load->library('mypagination' );

		$this->load->model('profile_model','profile');

		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');

	}


	function killSession()
	{
	}
	
	function index()
	{
		$this->killSession();
		$this->index_list();
	}
	
	function index_list()
	{
		$this->session->set_userdata('menu','1');
		$data['menu'] = '1';
        $data['myProfile'] = $this->profile->getMyProfile()->row_array();
        $data['myData'] = $this->profile->getMyActivities();
		$this->template->load('template','home',$data);
	}
	

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */