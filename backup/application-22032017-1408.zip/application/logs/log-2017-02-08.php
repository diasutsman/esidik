ERROR - 2017-02-08 16:11:06 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-02-08 16:11:06 --> Unable to connect to the database
ERROR - 2017-02-08 17:09:03 --> Query error: Table 'absensi_dagri.app_sessions' doesn't exist
ERROR - 2017-02-08 20:53:35 --> Query error: The user specified as a definer ('root'@'%') does not exist
ERROR - 2017-02-08 20:55:01 --> Query error: The user specified as a definer ('root'@'%') does not exist
ERROR - 2017-02-08 20:55:27 --> Query error: The user specified as a definer ('root'@'%') does not exist
