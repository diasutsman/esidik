<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-03-03 14:27:39 --> 404 Page Not Found --> 
ERROR - 2017-03-03 14:27:52 --> 404 Page Not Found --> 
ERROR - 2017-03-03 14:28:03 --> 404 Page Not Found --> 
ERROR - 2017-03-03 14:28:07 --> 404 Page Not Found --> 
