<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-02-16 12:56:54 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 12:56:54 --> Unable to connect to the database
ERROR - 2017-02-16 12:57:41 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 12:57:41 --> Unable to connect to the database
ERROR - 2017-02-16 12:57:41 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:41 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:42 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 12:57:42 --> Unable to connect to the database
ERROR - 2017-02-16 12:57:42 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 12:57:42 --> Severity: Warning  --> mysqli_num_rows() expects parameter 1 to be mysqli_result, null given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_result.php 37
ERROR - 2017-02-16 12:57:42 --> Severity: Warning  --> mysqli_num_rows() expects parameter 1 to be mysqli_result, null given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_result.php 37
ERROR - 2017-02-16 12:57:42 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:42 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:42 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:42 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:43 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 12:57:43 --> Unable to connect to the database
ERROR - 2017-02-16 12:57:43 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 12:57:43 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:43 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:44 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 12:57:44 --> Unable to connect to the database
ERROR - 2017-02-16 12:57:44 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 12:57:44 --> Severity: Warning  --> mysqli_num_rows() expects parameter 1 to be mysqli_result, null given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_result.php 37
ERROR - 2017-02-16 12:57:44 --> Severity: Warning  --> mysqli_num_rows() expects parameter 1 to be mysqli_result, null given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_result.php 37
ERROR - 2017-02-16 12:57:44 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:44 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:44 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:45 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 12:57:45 --> Unable to connect to the database
ERROR - 2017-02-16 12:57:45 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 12:57:45 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:45 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 12:57:46 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 12:57:46 --> Unable to connect to the database
ERROR - 2017-02-16 12:57:46 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 13:17:02 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 13:17:02 --> Unable to connect to the database
ERROR - 2017-02-16 13:17:02 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:02 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:03 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 13:17:03 --> Unable to connect to the database
ERROR - 2017-02-16 13:17:03 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 13:17:03 --> Severity: Warning  --> mysqli_num_rows() expects parameter 1 to be mysqli_result, null given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_result.php 37
ERROR - 2017-02-16 13:17:03 --> Severity: Warning  --> mysqli_num_rows() expects parameter 1 to be mysqli_result, null given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_result.php 37
ERROR - 2017-02-16 13:17:03 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:03 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:03 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:03 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:04 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 13:17:04 --> Unable to connect to the database
ERROR - 2017-02-16 13:17:04 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 13:17:04 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:04 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:05 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 13:17:05 --> Unable to connect to the database
ERROR - 2017-02-16 13:17:05 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 13:17:05 --> Severity: Warning  --> mysqli_num_rows() expects parameter 1 to be mysqli_result, null given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_result.php 37
ERROR - 2017-02-16 13:17:05 --> Severity: Warning  --> mysqli_num_rows() expects parameter 1 to be mysqli_result, null given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_result.php 37
ERROR - 2017-02-16 13:17:05 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:05 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:05 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:06 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 13:17:06 --> Unable to connect to the database
ERROR - 2017-02-16 13:17:06 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 13:17:06 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:06 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 320
ERROR - 2017-02-16 13:17:07 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 72
ERROR - 2017-02-16 13:17:07 --> Unable to connect to the database
ERROR - 2017-02-16 13:17:07 --> Severity: Warning  --> mysqli_query() expects parameter 1 to be mysqli, boolean given C:\woowtime7\apache2\htdocs\esidik\system\database\drivers\mysqli\mysqli_driver.php 179
ERROR - 2017-02-16 15:48:33 --> 404 Page Not Found --> 
ERROR - 2017-02-16 17:08:45 --> Severity: Notice  --> Undefined index:  C:\woowtime7\apache2\htdocs\esidik\application\modules\rpttunjangan\controllers\rpttunjangan.php 1035
ERROR - 2017-02-16 17:15:41 --> 404 Page Not Found --> 
