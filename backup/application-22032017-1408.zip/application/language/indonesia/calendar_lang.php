<?php

$lang['cal_su']			= "Minggu";
$lang['cal_mo'] 		= "Senin";
$lang['cal_tu'] 		= "Selasa";
$lang['cal_we'] 		= "Rabu";
$lang['cal_th'] 		= "Kamis";
$lang['cal_fr'] 		= "Jumat";
$lang['cal_sa'] 		= "Sabtu";
$lang['cal_sun'] 		= "Minggu";
$lang['cal_mon'] 		= "Senin";
$lang['cal_tue'] 		= "Selasa";
$lang['cal_wed'] 		= "Rabu";
$lang['cal_thu'] 		= "Kamis";
$lang['cal_fri'] 		= "Jumat";
$lang['cal_sat'] 		= "Sabtu";
$lang['cal_sunday']		= "Minggu";
$lang['cal_monday']		= "Senin";
$lang['cal_tuesday']	= "Selasa";
$lang['cal_wednesday']	= "Rabu";
$lang['cal_thursday']	= "Kamis";
$lang['cal_friday']		= "Jumat";
$lang['cal_saturday']	= "Sabtu";
$lang['cal_jan'] 		= "Jan";
$lang['cal_feb'] 		= "Feb";
$lang['cal_mar'] 		= "Mar";
$lang['cal_apr'] 		= "Apr";
$lang['cal_may'] 		= "May";
$lang['cal_jun'] 		= "Jun";
$lang['cal_jul'] 		= "Jul";
$lang['cal_aug'] 		= "Aug";
$lang['cal_sep'] 		= "Sep";
$lang['cal_oct'] 		= "Oct";
$lang['cal_nov'] 		= "Nov";
$lang['cal_dec'] 		= "Dec";
$lang['cal_january'] 	= "Januari";
$lang['cal_february'] 	= "Februari";
$lang['cal_march'] 		= "Maret";
$lang['cal_april']		= "April";
$lang['cal_may'] 		= "Mei";
$lang['cal_june'] 		= "Juni";
$lang['cal_july'] 		= "Juli";
$lang['cal_august']		= "Agustus";
$lang['cal_september']	= "September";
$lang['cal_october'] 	= "Oktober";
$lang['cal_november']	= "November";
$lang['cal_december'] 	= "Desember";


/* End of file calendar_lang.php */
/* Location: ./system/language/english/calendar_lang.php */
