<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Maps_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();


    }

    function getDisplayData($areaId=null)
    {

        if ($areaId != null)
        {
            $addwhere = " AND a.areaid in ('".implode("','", $areaId)."')";
        }

        $sql ="
                SELECT a.areaid,areaname,b.status,alias,sn 
                FROM personnel_area a
                INNER JOIN iclock b ON a.areaid=b.areaid
                WHERE 1=1 $addwhere   ";

        return $this->db->query($sql)->result_array();
    }


}

?>         