<?php
	
# include mPDF
require(APPPATH.'config/mpdf'.EXT);
require_once($mpdf['base_directory'].'/mpdf.php');
/**

 * class mpdf extends mPDF {
 * 	
 * 	function __construct() {
 * 		
 * 	}
 * 	
 * }
 */