<?php

$mpdf['base_directory'] = APPPATH.'third_party/mpdf50/';
$mpdf['fonts_directory'] = $mpdf['base_directory'].'fonts/';
