<?php  
if (!defined('BASEPATH')) exit('No direct script access allowed');
 
 
$config['simpeg_url']		=  "https://ropeg.setjen.kemendagri.go.id/";
$config['takah_url']		=  "https://takah.setjen.kemendagri.go.id/";
$config['epeforma_url']		=  "https://epeforma.setjen.kemendagri.go.id/";
$config['sisdahanik_url']	=  "http://absensi.setjen.kemendagri.go.id:8090/esidik/";
$config['webropeg_url']		=  "https://webropeg.kemendagri.go.id/";