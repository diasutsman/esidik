<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-31 18:51:35 --> 404 Page Not Found: /index
ERROR - 2023-12-31 18:55:18 --> 404 Page Not Found: /index
ERROR - 2023-12-31 18:55:22 --> 404 Page Not Found: /index
ERROR - 2023-12-31 18:57:44 --> Severity: Warning --> Undefined property: Login::$utils D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 18:57:44 --> Severity: error --> Exception: Call to a member function validation2() on null D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 18:58:47 --> Severity: Warning --> Undefined property: Login::$utils D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 18:58:47 --> Severity: error --> Exception: Call to a member function validation2() on null D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 18:59:37 --> 404 Page Not Found: /index
ERROR - 2023-12-31 18:59:40 --> Severity: Warning --> Undefined property: Login::$utils D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 18:59:40 --> Severity: error --> Exception: Call to a member function validation2() on null D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 18:59:58 --> Severity: 8192 --> Required parameter $array follows optional parameter $withttps D:\xampp80\htdocs\sisdahanik\application\helpers\utility_helper.php 1809
ERROR - 2023-12-31 18:59:59 --> Severity: Warning --> Undefined property: Login::$utils D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 18:59:59 --> Severity: error --> Exception: Call to a member function validation2() on null D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 19:01:35 --> Severity: Warning --> Undefined property: Login::$utils D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 19:01:35 --> Severity: error --> Exception: Call to a member function validation2() on null D:\xampp80\htdocs\sisdahanik\application\controllers\Login.php 88
ERROR - 2023-12-31 19:03:45 --> 404 Page Not Found: /index
ERROR - 2023-12-31 19:04:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Device_model D:\xampp80\htdocs\sisdahanik\system\core\Loader.php 344
